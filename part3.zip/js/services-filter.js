// Services Filter and Modal functionality
document.addEventListener('DOMContentLoaded', function () {
  // Filter functionality
  const filterButtons = document.querySelectorAll('.filter-btn')
  const serviceCards = document.querySelectorAll('.service-card')
  const activeFilter = document.getElementById('activeFilter')

  // Modal functionality
  const modal = document.getElementById('serviceModal')
  const modalTitle = document.getElementById('modalTitle')
  const modalDescription = document.getElementById('modalDescription')
  const modalFeatures = document.getElementById('modalFeatures')
  const modalAction = document.getElementById('modalAction')
  const closeModal = document.querySelector('.modal-close')

  // Filter services
  filterButtons.forEach(button => {
    button.addEventListener('click', function () {
      const filterValue = this.getAttribute('data-filter')

      // Update active filter button
      filterButtons.forEach(btn => btn.classList.remove('active'))
      this.classList.add('active')

      // Update active filter text
      activeFilter.textContent = this.textContent

      // Filter cards
      serviceCards.forEach(card => {
        if (
          filterValue === 'all' ||
          card.getAttribute('data-category') === filterValue
        ) {
          card.style.display = 'block'
          setTimeout(() => {
            card.style.opacity = '1'
            card.style.transform = 'translateY(0)'
          }, 100)
        } else {
          card.style.opacity = '0'
          card.style.transform = 'translateY(20px)'
          setTimeout(() => {
            card.style.display = 'none'
          }, 300)
        }
      })
    })
  })

  // Service data for modals
  const serviceData = {
    'educational-resources': {
      title: 'Educational Resources',
      description:
        'Access our comprehensive library of evidence-based articles, guides, and tools covering anxiety, depression, stress management, and overall mental wellness. All content is reviewed by mental health professionals.',
      features: [
        '200+ expert-written mental health articles',
        'Downloadable self-help guides and worksheets',
        'Video resources and recorded webinars',
        'Latest mental health research summaries',
        'Age-appropriate content for different audiences'
      ],
      action: 'Access Resources',
      link: 'enquiry.html'
    },
    'community-support': {
      title: 'Community Support',
      description:
        'Join our safe, moderated community forum where you can connect with others who understand your journey. Share experiences, find support, and build meaningful connections in a stigma-free environment.',
      features: [
        'Anonymous peer support forums',
        'Moderated group discussions',
        'Success stories and recovery journeys',
        '24/7 community access',
        'Professional moderation team'
      ],
      action: 'Join Community',
      link: 'enquiry.html'
    },
    'professional-guidance': {
      title: 'Professional Guidance',
      description:
        'Connect with licensed mental health professionals through our verified referral network. Get matched with therapists and counselors who specialize in your specific needs.',
      features: [
        'Verified therapist and counselor referrals',
        'Crisis intervention resources',
        'Professional consultation options',
        'Emergency support contacts',
        'Insurance and payment guidance'
      ],
      action: 'Get Professional Help',
      link: 'contact.html'
    },
    'workshops-programs': {
      title: 'Workshops & Programs',
      description:
        'Participate in our interactive workshops, webinars, and wellness programs designed to build resilience and coping skills for long-term mental health management.',
      features: [
        'Weekly mental wellness workshops',
        'Coping skills training sessions',
        'Mindfulness and meditation classes',
        'Educational webinars with experts',
        'Certificate programs available'
      ],
      action: 'View Programs',
      link: 'enquiry.html'
    },
    'crisis-support': {
      title: 'Emergency Support',
      description:
        'Immediate crisis support resources and emergency contacts for when you need urgent mental health assistance. Available 24/7 for immediate help.',
      features: [
        '24/7 crisis hotline connections',
        'Emergency contact information',
        'Crisis intervention guides',
        'Safety planning resources',
        'Local emergency services directory'
      ],
      action: 'Emergency Help',
      link: 'contact.html'
    },
    'volunteer-opportunities': {
      title: 'Get Involved',
      description:
        'Join our volunteer program and help support others while making a positive impact in the mental health community. Training and support provided.',
      features: [
        'Peer support training programs',
        'Community outreach initiatives',
        'Fundraising opportunities',
        'Awareness campaign participation',
        'Leadership development'
      ],
      action: 'Volunteer With Us',
      link: 'enquiry.html'
    }
  }

  // Open modal when service card is clicked
  serviceCards.forEach(card => {
    card.addEventListener('click', function () {
      const serviceId = this.getAttribute('data-service')
      const service = serviceData[serviceId]

      if (service) {
        openModal(service)
      }
    })
  })

  // Open modal function
  function openModal(service) {
    modalTitle.textContent = service.title
    modalDescription.textContent = service.description

    // Clear previous features
    modalFeatures.innerHTML = ''

    // Add features
    service.features.forEach(feature => {
      const li = document.createElement('li')
      li.textContent = feature
      modalFeatures.appendChild(li)
    })

    // Update action button
    modalAction.textContent = service.action
    modalAction.href = service.link

    // Show modal
    modal.style.display = 'flex'
    document.body.style.overflow = 'hidden'

    // Add animation
    setTimeout(() => {
      modal.querySelector('.modal-content').style.transform = 'scale(1)'
      modal.querySelector('.modal-content').style.opacity = '1'
    }, 10)
  }

  // Close modal functions
  closeModal.addEventListener('click', closeModalHandler)

  modal.addEventListener('click', function (e) {
    if (e.target === modal) {
      closeModalHandler()
    }
  })

  // Close with Escape key
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && modal.style.display === 'flex') {
      closeModalHandler()
    }
  })

  function closeModalHandler() {
    modal.querySelector('.modal-content').style.transform = 'scale(0.9)'
    modal.querySelector('.modal-content').style.opacity = '0'

    setTimeout(() => {
      modal.style.display = 'none'
      document.body.style.overflow = 'auto'
    }, 300)
  }

  // Search functionality
  const searchInput = document.getElementById('serviceSearch')
  if (searchInput) {
    searchInput.addEventListener('input', function () {
      const searchTerm = this.value.toLowerCase()

      serviceCards.forEach(card => {
        const title = card.querySelector('h3').textContent.toLowerCase()
        const description = card.querySelector('p').textContent.toLowerCase()

        if (title.includes(searchTerm) || description.includes(searchTerm)) {
          card.style.display = 'block'
          setTimeout(() => {
            card.style.opacity = '1'
            card.style.transform = 'translateY(0)'
          }, 100)
        } else {
          card.style.opacity = '0'
          card.style.transform = 'translateY(20px)'
          setTimeout(() => {
            card.style.display = 'none'
          }, 300)
        }
      })
    })
  }
})
