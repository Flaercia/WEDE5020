// Contact Page Map and Form functionality
document.addEventListener('DOMContentLoaded', function () {
  // Initialize Leaflet Map
  initMap()

  // Initialize Contact Form
  initContactForm()
})

function initMap() {
  const mapContainer = document.getElementById('pawhopeMap')
  if (!mapContainer) return

  // Initialize the map centered on Melbourne
  const map = L.map('pawhopeMap').setView([-37.8136, 144.9631], 13)

  // Add OpenStreetMap tiles
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution:
      '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
    maxZoom: 18
  }).addTo(map)

  // Custom icons
  const mainIcon = L.divIcon({
    className: 'map-marker',
    html: '🏢',
    iconSize: [30, 30],
    iconAnchor: [15, 30]
  })

  const supportIcon = L.divIcon({
    className: 'map-marker',
    html: '🤝',
    iconSize: [30, 30],
    iconAnchor: [15, 30]
  })

  const partnerIcon = L.divIcon({
    className: 'map-marker',
    html: '🏥',
    iconSize: [30, 30],
    iconAnchor: [15, 30]
  })

  // Locations data
  const locations = [
    {
      coords: [-37.8136, 144.9631],
      title: 'Serene Mind Main Office',
      type: 'main',
      address: '123 Wellness Street, Melbourne VIC 3000',
      phone: '+61 123 456 789',
      hours: 'Mon-Fri: 9:00 AM - 6:00 PM',
      services: 'Administration, General Enquiries, Resource Center'
    },
    {
      coords: [-37.815, 144.965],
      title: 'Support Center',
      type: 'support',
      address: '456 Hope Avenue, Melbourne VIC 3000',
      phone: '+61 123 456 788',
      hours: 'Mon-Sun: 8:00 AM - 8:00 PM',
      services: 'Counseling Sessions, Support Groups, Emergency Support'
    },
    {
      coords: [-37.812, 144.961],
      title: 'Partner Clinic',
      type: 'partner',
      address: '789 Care Boulevard, Melbourne VIC 3000',
      phone: '+61 123 456 787',
      hours: 'Mon-Fri: 8:00 AM - 5:00 PM',
      services: 'Professional Therapy, Medical Consultations'
    }
  ]

  // Add markers to the map
  locations.forEach(function (location) {
    let icon
    switch (location.type) {
      case 'support':
        icon = supportIcon
        break
      case 'partner':
        icon = partnerIcon
        break
      default:
        icon = mainIcon
    }

    const marker = L.marker(location.coords, { icon: icon }).addTo(map)

    // Create popup content
    const popupContent = `
            <div class="map-popup">
                <h4>${location.title}</h4>
                <div class="popup-info">
                    <p><strong>Address:</strong> ${location.address}</p>
                    <p><strong>Phone:</strong> ${location.phone}</p>
                    <p><strong>Hours:</strong> ${location.hours}</p>
                    <p><strong>Services:</strong> ${location.services}</p>
                </div>
                <div class="popup-actions">
                    <button onclick="getDirections(${location.coords[0]}, ${location.coords[1]})" 
                            class="direction-btn">Get Directions</button>
                    <button onclick="callNumber('${location.phone}')" 
                            class="call-btn">Call Location</button>
                </div>
            </div>
        `

    marker.bindPopup(popupContent)
  })

  // Map controls
  const focusMainBtn = document.getElementById('focusMainOffice')
  if (focusMainBtn) {
    focusMainBtn.addEventListener('click', function () {
      map.setView([-37.8136, 144.9631], 15)
      // Open the main office popup
      setTimeout(function () {
        map.eachLayer(function (layer) {
          if (layer instanceof L.Marker) {
            const latlng = layer.getLatLng()
            if (latlng.lat === -37.8136 && latlng.lng === 144.9631) {
              layer.openPopup()
            }
          }
        })
      }, 500)
    })
  }
}

function initContactForm() {
  const contactForm = document.getElementById('contactForm')
  const formResponse = document.getElementById('formResponse')

  if (contactForm) {
    contactForm.addEventListener('submit', function (e) {
      e.preventDefault()

      if (validateContactForm()) {
        submitContactForm()
      }
    })

    // Real-time validation
    const inputs = ['fullname', 'email', 'subject', 'message']
    inputs.forEach(inputId => {
      const input = document.getElementById(inputId)
      if (input) {
        input.addEventListener('blur', function () {
          validateContactField(this.id)
        })
      }
    })

    // Character counter for message
    const messageField = document.getElementById('message')
    if (messageField) {
      const counter = document.createElement('div')
      counter.className = 'char-counter'
      counter.id = 'charCounter'
      counter.textContent = '0/1000'
      messageField.parentNode.appendChild(counter)

      messageField.addEventListener('input', function () {
        const length = this.value.length
        counter.textContent = `${length}/1000`

        if (length > 900) {
          counter.style.color = '#e74c3c'
        } else if (length > 800) {
          counter.style.color = '#f39c12'
        } else {
          counter.style.color = '#666'
        }
      })
    }
  }
}

function validateContactForm() {
  clearContactErrors()
  let isValid = true

  const fields = ['fullname', 'email', 'subject', 'message']
  fields.forEach(field => {
    if (!validateContactField(field)) {
      isValid = false
    }
  })

  return isValid
}

function validateContactField(fieldId) {
  const field = document.getElementById(fieldId)
  const value = field.value.trim()

  switch (fieldId) {
    case 'fullname':
      if (!value) {
        showContactError(field, 'Please enter your full name')
        return false
      }
      if (value.length < 2) {
        showContactError(field, 'Name must be at least 2 characters long')
        return false
      }
      break

    case 'email':
      if (!value) {
        showContactError(field, 'Please enter your email address')
        return false
      }
      if (!isValidEmail(value)) {
        showContactError(field, 'Please enter a valid email address')
        return false
      }
      break

    case 'subject':
      if (!value) {
        showContactError(field, 'Please enter a subject')
        return false
      }
      if (value.length < 5) {
        showContactError(field, 'Subject must be at least 5 characters long')
        return false
      }
      break

    case 'message':
      if (!value) {
        showContactError(field, 'Please enter your message')
        return false
      }
      if (value.length < 10) {
        showContactError(field, 'Message must be at least 10 characters long')
        return false
      }
      if (value.length > 1000) {
        showContactError(field, 'Message must be less than 1000 characters')
        return false
      }
      break
  }

  clearContactFieldError(fieldId)
  return true
}

function isValidEmail(email) {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  return emailRegex.test(email)
}

function showContactError(field, message) {
  clearContactFieldError(field.id)

  const errorElement = document.createElement('div')
  errorElement.className = 'error-message'
  errorElement.textContent = message
  errorElement.id = `${field.id}-error`

  field.parentNode.appendChild(errorElement)
  field.classList.add('error')
}

function clearContactFieldError(fieldId) {
  const errorElement = document.getElementById(`${fieldId}-error`)
  if (errorElement) {
    errorElement.remove()
  }

  const field = document.getElementById(fieldId)
  if (field) {
    field.classList.remove('error')
  }
}

function clearContactErrors() {
  const errorMessages = document.querySelectorAll('.error-message')
  errorMessages.forEach(error => error.remove())

  const errorFields = document.querySelectorAll('.error')
  errorFields.forEach(field => field.classList.remove('error'))
}

function submitContactForm() {
  const submitBtn = document.querySelector('#contactForm .submit-button')
  const originalText = submitBtn.textContent

  // Show loading state
  submitBtn.textContent = 'Sending...'
  submitBtn.disabled = true

  // Get form data
  const formData = {
    name: document.getElementById('fullname').value,
    email: document.getElementById('email').value,
    subject: document.getElementById('subject').value,
    message: document.getElementById('message').value,
    timestamp: new Date().toISOString()
  }

  // Simulate API call
  setTimeout(() => {
    const response = generateContactResponse(formData)
    showContactResponse(response)
    resetContactForm()

    // Restore button
    submitBtn.textContent = originalText
    submitBtn.disabled = false
  }, 2000)
}

function generateContactResponse(formData) {
  return `
        <div class="response-success">
            <div class="response-icon">✅</div>
            <h3>Message Sent Successfully!</h3>
            <p>Thank you for contacting Serene Mind, <strong>${
              formData.name
            }</strong>!</p>
            
            <div class="response-details">
                <h4>Message Summary:</h4>
                <ul>
                    <li><strong>Subject:</strong> ${formData.subject}</li>
                    <li><strong>Contact Email:</strong> ${formData.email}</li>
                    <li><strong>Submitted:</strong> ${new Date().toLocaleString()}</li>
                </ul>
            </div>
            
            <div class="next-steps">
                <h4>What Happens Next:</h4>
                <ul>
                    <li>You'll receive a confirmation email shortly</li>
                    <li>Our team will review your message within 24 hours</li>
                    <li>We'll respond to your enquiry personally</li>
                    <li>For urgent matters, we may contact you by phone</li>
                </ul>
            </div>
            
            <div class="response-actions">
                <button onclick="closeContactResponse()" class="btn btn-secondary">Close</button>
                <a href="enquiry.html" class="btn btn-primary">Make Another Enquiry</a>
            </div>
        </div>
    `
}

function showContactResponse(responseHTML) {
  const formResponse = document.getElementById('formResponse')
  if (formResponse) {
    formResponse.innerHTML = responseHTML
    formResponse.style.display = 'block'
    formResponse.scrollIntoView({ behavior: 'smooth', block: 'start' })
  }
}

function resetContactForm() {
  const form = document.getElementById('contactForm')
  if (form) {
    form.reset()
    clearContactErrors()

    // Reset character counter
    const charCounter = document.getElementById('charCounter')
    if (charCounter) {
      charCounter.textContent = '0/1000'
      charCounter.style.color = '#666'
    }
  }
}

// Global functions
function closeContactResponse() {
  const formResponse = document.getElementById('formResponse')
  if (formResponse) {
    formResponse.style.display = 'none'
  }
}

function resetContactForm() {
  const form = document.getElementById('contactForm')
  if (form) {
    form.reset()
    clearContactErrors()
    closeContactResponse()

    const charCounter = document.getElementById('charCounter')
    if (charCounter) {
      charCounter.textContent = '0/1000'
      charCounter.style.color = '#666'
    }
  }
}

// Map utility functions
function getDirections(lat, lng) {
  const url = `https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}`
  window.open(url, '_blank')
}

function callNumber(phone) {
  const cleanPhone = phone.replace(/[^\d+]/g, '')
  window.location.href = `tel:${cleanPhone}`
}

function locateUser() {
  const map = L.map('pawhopeMap')

  if (!navigator.geolocation) {
    alert('Geolocation is not supported by this browser.')
    return
  }

  navigator.geolocation.getCurrentPosition(
    function (position) {
      const userLat = position.coords.latitude
      const userLng = position.coords.longitude

      map.setView([userLat, userLng], 13)

      // Add user location marker
      const userIcon = L.divIcon({
        className: 'user-marker',
        html: '📍',
        iconSize: [25, 25],
        iconAnchor: [12, 25]
      })

      L.marker([userLat, userLng], { icon: userIcon })
        .addTo(map)
        .bindPopup('Your current location')
        .openPopup()
    },
    function (error) {
      alert('Unable to get your location. Please enable location services.')
    }
  )
}
