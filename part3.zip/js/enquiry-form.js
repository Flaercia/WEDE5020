// Enquiry Form Validation and Submission
document.addEventListener('DOMContentLoaded', function () {
  const enquiryForm = document.getElementById('enquiryForm')
  const formResponse = document.getElementById('formResponse')

  if (enquiryForm) {
    enquiryForm.addEventListener('submit', function (e) {
      e.preventDefault()

      if (validateForm()) {
        submitEnquiry()
      }
    })

    // Real-time validation
    setupRealTimeValidation()
  }

  function setupRealTimeValidation() {
    const inputs = ['name', 'email', 'phone', 'service', 'urgency', 'message']

    inputs.forEach(inputId => {
      const input = document.getElementById(inputId)
      if (input) {
        input.addEventListener('blur', function () {
          validateField(this.id)
        })

        input.addEventListener('input', function () {
          clearFieldError(this.id)
        })
      }
    })
  }

  function validateForm() {
    let isValid = true
    const fields = ['name', 'email', 'service', 'message']

    fields.forEach(field => {
      if (!validateField(field)) {
        isValid = false
      }
    })

    return isValid
  }

  function validateField(fieldId) {
    const field = document.getElementById(fieldId)
    const value = field.value.trim()

    switch (fieldId) {
      case 'name':
        if (!value) {
          showError(field, 'Please enter your full name')
          return false
        }
        if (value.length < 2) {
          showError(field, 'Name must be at least 2 characters long')
          return false
        }
        break

      case 'email':
        if (!value) {
          showError(field, 'Please enter your email address')
          return false
        }
        if (!isValidEmail(value)) {
          showError(field, 'Please enter a valid email address')
          return false
        }
        break

      case 'phone':
        if (value && !isValidPhone(value)) {
          showError(field, 'Please enter a valid phone number')
          return false
        }
        break

      case 'service':
        if (!value) {
          showError(field, 'Please select a service')
          return false
        }
        break

      case 'message':
        if (!value) {
          showError(field, 'Please enter your message')
          return false
        }
        if (value.length < 10) {
          showError(field, 'Message must be at least 10 characters long')
          return false
        }
        if (value.length > 1000) {
          showError(field, 'Message must be less than 1000 characters')
          return false
        }
        break
    }

    clearFieldError(fieldId)
    return true
  }

  function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    return emailRegex.test(email)
  }

  function isValidPhone(phone) {
    const phoneRegex = /^[\d\s\-\(\)\+]+$/
    const cleanPhone = phone.replace(/\D/g, '')
    return phoneRegex.test(phone) && cleanPhone.length >= 10
  }

  function showError(field, message) {
    // Remove existing error
    clearFieldError(field.id)

    // Add error message
    const errorElement = document.createElement('div')
    errorElement.className = 'error-message'
    errorElement.textContent = message
    errorElement.id = `${field.id}-error`

    field.parentNode.appendChild(errorElement)
    field.classList.add('error')
  }

  function clearFieldError(fieldId) {
    const errorElement = document.getElementById(`${fieldId}-error`)
    if (errorElement) {
      errorElement.remove()
    }

    const field = document.getElementById(fieldId)
    if (field) {
      field.classList.remove('error')
    }
  }

  function clearAllErrors() {
    const errorMessages = document.querySelectorAll('.error-message')
    errorMessages.forEach(error => error.remove())

    const errorFields = document.querySelectorAll('.error')
    errorFields.forEach(field => field.classList.remove('error'))
  }

  function submitEnquiry() {
    const submitBtn = document.querySelector('#enquiryForm .submit-button')
    const originalText = submitBtn.textContent

    // Show loading state
    submitBtn.textContent = 'Sending...'
    submitBtn.disabled = true

    // Get form data
    const formData = {
      name: document.getElementById('name').value,
      email: document.getElementById('email').value,
      phone: document.getElementById('phone').value,
      service: document.getElementById('service').value,
      urgency: document.getElementById('urgency').value,
      message: document.getElementById('message').value,
      timestamp: new Date().toISOString()
    }

    // Simulate API call
    setTimeout(() => {
      const response = generateResponse(formData)
      showResponse(response)
      resetForm()

      // Restore button
      submitBtn.textContent = originalText
      submitBtn.disabled = false
    }, 2000)
  }

  function generateResponse(formData) {
    const serviceNames = {
      counseling: 'Professional Counseling',
      therapy: 'Therapy Sessions',
      'support-group': 'Support Group',
      workshop: 'Wellness Workshop',
      resources: 'Educational Resources',
      volunteer: 'Volunteer Program'
    }

    const urgencyLevels = {
      low: 'Low',
      medium: 'Medium',
      high: 'High',
      crisis: 'Crisis - Immediate'
    }

    const serviceName = serviceNames[formData.service] || formData.service
    const urgencyText = urgencyLevels[formData.urgency] || 'Not specified'

    let responseHTML = `
            <div class="response-success">
                <div class="response-icon">✅</div>
                <h3>Thank You, ${formData.name}!</h3>
                <p>Your enquiry has been received successfully.</p>
                
                <div class="response-details">
                    <h4>Enquiry Summary:</h4>
                    <ul>
                        <li><strong>Service:</strong> ${serviceName}</li>
                        <li><strong>Urgency:</strong> ${urgencyText}</li>
                        <li><strong>Contact Email:</strong> ${
                          formData.email
                        }</li>
                        ${
                          formData.phone
                            ? `<li><strong>Phone:</strong> ${formData.phone}</li>`
                            : ''
                        }
                    </ul>
                </div>
        `

    // Add specific instructions based on service and urgency
    if (formData.urgency === 'crisis') {
      responseHTML += `
                <div class="emergency-notice">
                    <h4>🚨 Immediate Support Available</h4>
                    <p>Based on your urgency level, we recommend:</p>
                    <ul>
                        <li>Call National Suicide Prevention Lifeline: <strong>988</strong></li>
                        <li>Text Crisis Text Line: <strong>HOME to 741741</strong></li>
                        <li>Go to your nearest emergency room</li>
                    </ul>
                    <p>Our team will also contact you within the next 30 minutes.</p>
                </div>
            `
    } else if (
      formData.service === 'counseling' ||
      formData.service === 'therapy'
    ) {
      responseHTML += `
                <div class="next-steps">
                    <h4>Next Steps:</h4>
                    <ul>
                        <li>Our intake coordinator will contact you within 24 hours</li>
                        <li>We'll match you with a suitable mental health professional</li>
                        <li>Schedule your initial consultation session</li>
                        <li>Discuss treatment options and preferences</li>
                    </ul>
                </div>
            `
    } else {
      responseHTML += `
                <div class="next-steps">
                    <h4>What Happens Next:</h4>
                    <ul>
                        <li>You'll receive a confirmation email shortly</li>
                        <li>Our team will review your enquiry within 1-2 business days</li>
                        <li>We'll contact you with specific information and resources</li>
                        <li>Follow-up support will be provided as needed</li>
                    </ul>
                </div>
            `
    }

    responseHTML += `
                <div class="response-actions">
                    <button onclick="closeResponse()" class="btn btn-secondary">Close</button>
                    <a href="contact.html" class="btn btn-primary">Contact Us Again</a>
                </div>
            </div>
        `

    return responseHTML
  }

  function showResponse(responseHTML) {
    if (formResponse) {
      formResponse.innerHTML = responseHTML
      formResponse.style.display = 'block'
      formResponse.scrollIntoView({ behavior: 'smooth', block: 'start' })
    }
  }

  function resetForm() {
    enquiryForm.reset()
    clearAllErrors()

    // Reset character counter
    const messageField = document.getElementById('message')
    const charCounter = document.getElementById('charCounter')
    if (messageField && charCounter) {
      charCounter.textContent = '0/1000'
      charCounter.style.color = '#666'
    }
  }

  // Character counter for message field
  const messageField = document.getElementById('message')
  if (messageField) {
    const counter = document.createElement('div')
    counter.className = 'char-counter'
    counter.id = 'charCounter'
    counter.textContent = '0/1000'
    messageField.parentNode.appendChild(counter)

    messageField.addEventListener('input', function () {
      const length = this.value.length
      counter.textContent = `${length}/1000`

      if (length > 900) {
        counter.style.color = '#e74c3c'
      } else if (length > 800) {
        counter.style.color = '#f39c12'
      } else {
        counter.style.color = '#666'
      }
    })
  }

  // Service-specific field toggling
  const serviceSelect = document.getElementById('service')
  const volunteerFields = document.getElementById('volunteerFields')

  if (serviceSelect && volunteerFields) {
    serviceSelect.addEventListener('change', function () {
      if (this.value === 'volunteer') {
        volunteerFields.style.display = 'block'
      } else {
        volunteerFields.style.display = 'none'
      }
    })
  }
})

// Global functions
function closeResponse() {
  const formResponse = document.getElementById('formResponse')
  if (formResponse) {
    formResponse.style.display = 'none'
  }
}

function resetEnquiryForm() {
  const form = document.getElementById('enquiryForm')
  if (form) {
    form.reset()

    // Reset volunteer fields
    const volunteerFields = document.getElementById('volunteerFields')
    if (volunteerFields) {
      volunteerFields.style.display = 'none'
    }

    // Reset character counter
    const charCounter = document.getElementById('charCounter')
    if (charCounter) {
      charCounter.textContent = '0/1000'
      charCounter.style.color = '#666'
    }

    closeResponse()
  }
}
