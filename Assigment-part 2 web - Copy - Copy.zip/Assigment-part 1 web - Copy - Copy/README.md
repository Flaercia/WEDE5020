# Serene Mind

##  Description
**Serene Mind** is a website dedicated to **mental health, wellness, and psychological support**.  
This project was developed as part of an academic assignment with the goal of **informing, supporting, and connecting people** to mental health resources.

The website is built using **HTML5** and styled with **CSS3** (a single external file), following best practices for **semantics, responsive design, and intuitive navigation**.

---

##  Project Structure
 **SereneMind**  
 ┣ **index.html** → Home page  
 ┣ **about.html** → About us (mission, vision, story, audience)  
 ┣  **Products&services.html** → Products & Services (cards navigation)  
 ┣  **enquiry.html** → Enquiry form (support requests & volunteering)  
 ┣ **contact.html** → Contact page (form + Google Map)  
 ┣  **style.css** → Global stylesheet  
 ┣ **img/** → Logos and images  
 ┗  **README.md** → Project documentation  

---

## Technologies Used
- **HTML5** → semantic and accessible structure  
- **CSS3** → styling, uniform typography, flex/grid layout  
- **Media Queries** → adaptation to different devices (desktop, tablet, mobile)  

---

##  Responsiveness
The website is fully responsive and adapts to different screen sizes:
- **Desktop (≥ 1024px)**  
- **Tablet (768px – 1023px)**  
- **Mobile (≤ 767px)**  

---

## Features
- **Home Page:** hero section with main message and call-to-action button.  
- **About Us:** description of history, mission, vision, and target audience.  
- **Products & Services:** interactive cards for navigation across key sections.  
- **Enquiry:** form to request support, join services, or volunteer.  
- **Contact:** contact form + embedded Google Map.  
- **Uniform footer** across all pages.  

##  How to Run the Project
1. Download or clone this repository.  
2. Open the folder in **VS Code** or another editor.  
3. Simply double-click on `index.html` → it will open in your browser.  
4. You can navigate between pages using the navigation bar.  

---

##  Future Improvements
- Add a **blog section** with articles about mental health.  
- Implement **multi-language support** (English, Portuguese, etc.).  
- Enhance **accessibility** with ARIA labels.  
- Add a **chatbot or live chat** for instant support.  
- Improve form validation with **JavaScript**.  

---

## Author
Project developed by **Flaercia Lopes**  
Course: **[DISD]**  
Academic Year: **2025**

---

## References
- Visual inspiration from health and wellness websites.  
- Icons and images from personal repository (`/img`).  
- Structure based on **HTML5 and CSS3** best practices.